import { Request, Response } from 'express';
import {
  controller,
  catchError,
  requiredProps,
  use,
  get,
  post,
  put,
  del,
} from '../../decorators';
import { CustomError } from '../../interfaces/customError';
import { isAuth } from '../../middlewares/isAuth';
import { ReportType } from '../../models';
import { Role, ReportedType } from '../../util/types';

@controller('/admin')
class reportType {
  @catchError
  @requiredProps('name', 'description', 'reportedType')
  @post('/reportType')
  @use(isAuth)
  async addReportType(req: Request, res: Response) {
    let { name, description, reportedType } = req.body;
    reportedType = reportedType.toLowerCase();
    if (reportedType !== 'worker' && reportedType !== 'shop') {
      const error = new CustomError('Reported type is not valid!');
      error.statusCode = 422;
      throw error;
    }
    reportedType = ReportedType[reportedType as keyof typeof ReportedType];
    const reportType = new ReportType({ name, description, reportedType });
    await reportType.save();
    res.status(201).json({ message: 'Report type added successfully.' });
  }
  @catchError
  @get('/reportTypes')
  @use(isAuth)
  async getReportTypes(req: Request, res: Response) {
    const reportTypes = await ReportType.find();
    res.status(200).json({ message: 'Report types: ', reportTypes });
  }
  @catchError
  @put('/reportType/:reportTypeId')
  @use(isAuth)
  async editReportTypes(req: Request, res: Response) {
    req.body.reportedType = req.body.reportedType.toLowerCase();
    if (
      req.body.reportedType !== 'worker' &&
      req.body.reportedType !== 'shop'
    ) {
      const error = new CustomError('Reported type is not valid!');
      error.statusCode = 422;
      throw error;
    }
    req.body.reportedType =
      ReportedType[req.body.reportedType as keyof typeof ReportedType];
    const { reportTypeId } = req.params;
    const reportType = await ReportType.findById(reportTypeId);
    if (!reportType) {
      const error = new CustomError('Report type not found!');
      error.statusCode = 404;
      throw Error;
    }
    for (const key in req.body) {
      if (req.body[key]) (reportType as any)[key] = req.body[key];
    }
    await reportType.save();
    res.status(201).json({ message: 'Report type updated successfully.' });
  }
  @catchError
  @del('/reportType/:reportTypeId')
  @use(isAuth)
  async deleteReportType(req: Request, res: Response) {
    const { reportTypeId } = req.params;
    const reportType = await ReportType.findByIdAndDelete(reportTypeId);
    if (!reportType) {
      const error = new CustomError('Report type not found!');
      error.statusCode = 404;
      throw error;
    }
    res.status(201).json({ message: 'Report type deleted successfully.' });
  }
}
