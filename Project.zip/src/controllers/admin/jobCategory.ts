import { Request, Response } from 'express';
import {
  controller,
  catchError,
  requiredProps,
  use,
  get,
  post,
  put,
  del,
} from '../../decorators';
import { CustomError } from '../../interfaces/customError';
import { isAuth } from '../../middlewares/isAuth';
import { JobCategory } from '../../models';
import { Role } from '../../util/types';
@controller('/admin')
class jobCategory {
  @catchError
  @requiredProps('name', 'description')
  @post('/jobCategory')
  @use(isAuth)
  async addJobCategory(req: Request, res: Response): Promise<void> {
    // if (req.role !== Role.admin) {
    //   const error = new CustomError('Unauthorized!');
    //   error.statusCode = 401;
    //   throw error;
    // }
    const { name, description } = req.body;
    const jobCategory = new JobCategory({ name, description });
    await jobCategory.save();
    res.status(201).json({ message: 'Job category created.' });
  }

  @catchError
  @put('/jobCategory/:jobCategoryId')
  @use(isAuth)
  async editJobCategory(req: Request, res: Response) {
    // if (req.role !== Role.admin) {
    //   const error = new CustomError('Unauthorized!');
    //   error.statusCode = 401;
    //   throw error;
    // }
    const { name, description } = req.body;
    const { jobCategoryId } = req.params;
    const jobCategory = await JobCategory.findById(jobCategoryId);
    if (!jobCategory) {
      const error = new CustomError('Job category not found!');
      error.statusCode = 404;
      throw error;
    }
    jobCategory.name = name || jobCategory.name;
    jobCategory.description = description || jobCategory.description;
    await jobCategory.save();
    res.status(201).json({ message: 'Job category updated.' });
  }
  @catchError
  @del('/jobCategory/:jobCategoryId')
  @use(isAuth)
  async deleteJobCategory(req: Request, res: Response) {
    // if (req.role !== Role.admin) {
    //   const error = new CustomError('Unauthorized!');
    //   error.statusCode = 401;
    //   throw error;
    // }
    const { jobCategoryId } = req.params;
    const jobCategory = await JobCategory.findByIdAndDelete(jobCategoryId);
    if (!jobCategory) {
      const error = new CustomError('Job category not found!');
      error.statusCode = 404;
      throw error;
    }
    res.status(201).json({ message: 'Job category deleted.' });
  }
}
