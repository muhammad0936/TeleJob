import { Request, Response } from 'express';
import {
  controller,
  catchError,
  get,
  requiredProps,
  post,
  use,
  validate,
} from '../../decorators';
import { CustomError } from '../../interfaces/customError';
import { sign } from 'jsonwebtoken';
import { Role } from '../../util/types';
import { loginValidator } from '../../validators/admin';
@controller('/admin')
class adminController {
  @catchError
  @requiredProps('email', 'password')
  @post('/login')
  @validate(loginValidator)
  async login(req: Request, res: Response): Promise<void> {
    const { email, password } = req.body;
    if (
      email !== process.env.admin_account ||
      password !== process.env.admin_password
    ) {
      const error = new CustomError('Wrong credentials!');
      error.statusCode = 401;
      throw error;
    }
    const jwt = sign(
      { email: email, userId: process.env.adminId, role: Role.admin },
      process.env.jwt_secrete_string as string,
      { expiresIn: '24h' }
    );
    res.status(200).json({ message: 'Loged in successfully.', JWT: jwt });
  }
}
