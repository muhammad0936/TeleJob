import { Request, Response } from 'express';
import {
  controller,
  catchError,
  requiredProps,
  use,
  get,
  post,
  put,
  del,
} from '../../decorators';
import { CustomError } from '../../interfaces/customError';
import { isAuth } from '../../middlewares/isAuth';
import { ShopCategory } from '../../models';
import { Role } from '../../util/types';
@controller('/admin')
class shopCategory {
  @catchError
  @requiredProps('name', 'description')
  @post('/shopCategory')
  @use(isAuth)
  async addShopCategory(req: Request, res: Response): Promise<void> {
    if (req.role !== Role.admin) {
      const error = new CustomError('Unauthorized!');
      error.statusCode = 401;
      throw error;
    }
    const { name, description } = req.body;
    const shopCategory = new ShopCategory({ name, description });
    await shopCategory.save();
    res.status(201).json({ message: 'Shop category created.' });
  }

  @catchError
  @put('/shopCategory/:shopCategoryId')
  @use(isAuth)
  async editShopCategory(req: Request, res: Response) {
    console.log('hiiiii');
    if (req.role !== Role.admin) {
      const error = new CustomError('Unauthorized!');
      error.statusCode = 401;
      throw error;
    }
    const { name, description } = req.body;
    const { shopCategoryId } = req.params;
    const shopCategory = await ShopCategory.findById(shopCategoryId);
    if (!shopCategory) {
      const error = new CustomError('Shop category not found!');
      error.statusCode = 404;
      throw error;
    }
    shopCategory.name = name || shopCategory.name;
    shopCategory.description = description || shopCategory.description;
    await shopCategory.save();
    res.status(201).json({ message: 'Shop category updated.' });
  }
  @catchError
  @del('/shopCategory/:shopCategoryId')
  @use(isAuth)
  async deleteShopCategory(req: Request, res: Response) {
    if (req.role !== Role.admin) {
      const error = new CustomError('Unauthorized!');
      error.statusCode = 401;
      throw error;
    }
    const { shopCategoryId } = req.params;
    const shopCategory = await ShopCategory.findByIdAndDelete(shopCategoryId);
    if (!shopCategory) {
      const error = new CustomError('Shop category not found!');
      error.statusCode = 404;
      throw error;
    }
    res.status(201).json({ message: 'Shop category deleted.' });
  }
}
