import {
  controller,
  get,
  post,
  put,
  requiredProps,
  use,
} from '../../decorators';
import { CustomError } from '../../interfaces/customError';
import { catchError } from '../../decorators/catchError';
import { Request, Response, NextFunction } from 'express';
import { hash, compare } from 'bcrypt';
import { sign } from 'jsonwebtoken';
import { Order, Product, Shop } from '../../models';
import { isAuth } from '../../middlewares/isAuth';
import { OrderStatus } from '../../util/types';

@controller('/shop')
class shop {
  @catchError
  @get('/orders')
  @use(isAuth)
  async getOrders(req: Request, res: Response) {
    const shop = await Shop.exists({ _id: req.userId });
    if (!shop) throw new CustomError('Unauthorized!', 401);
    const orders = await Order.find({ shop: req.userId })
      .select('_id description status totalPrice products')
      .populate({ path: 'worker', select: 'name' });
    res.status(200).json({ message: 'Your orders: ', orders });
  }

  @catchError
  @put('/order/:orderId')
  @use(isAuth)
  async respondToOrder(req: Request, res: Response) {
    const { orderId } = req.params;
    var { responseType }: { responseType: string } = req.body;
    responseType = responseType.toLowerCase();
    if (responseType !== 'accept' && responseType !== 'reject')
      throw new CustomError(
        "Use valid response type, Either 'Accept' or 'Reject'.!",
        400
      );
    const order = await Order.findById(orderId);
    if (!order) throw new CustomError('Order not found!', 404);
    const shop = await Shop.findById(req.userId);
    if (!shop || order.shop.toString() !== shop._id.toString())
      throw new CustomError('Unauthorized!', 401);
    //************** */
    if (order.status === OrderStatus.rejected)
      throw new CustomError('You already rejected this order!', 400);
    if (order.status === OrderStatus.accepted)
      throw new CustomError('You already accepted this order!', 400);
    if (+order.endDate < Date.now())
      throw new CustomError('This order has expired!', 410);
    order.status = OrderStatus[`${responseType}ed`];
    order.endDate =
      responseType === 'accept'
        ? new Date(Date.now() + 1800000) //30minutes to deliver the order
        : new Date(Date.now());
    await order.save();
    res.status(201).json({ message: `The order ${responseType}ed.` });
  }
}
