import {
  controller,
  del,
  get,
  post,
  put,
  requiredProps,
  use,
} from '../../decorators';
import { CustomError } from '../../interfaces/customError';
import { catchError } from '../../decorators/catchError';
import { Request, Response, NextFunction } from 'express';
import { hash, compare } from 'bcrypt';
import { sign } from 'jsonwebtoken';
import { Product, Shop } from '../../models';
import { isAuth } from '../../middlewares/isAuth';

@controller('/shop')
class shop {
  @catchError
  @get('/products')
  @use(isAuth)
  async getProducts(req: Request, res: Response) {
    const shop = await Shop.findById(req.userId).populate({
      path: 'Products',
      select: 'name description price imagesUrls',
    });
    if (!shop) throw new CustomError('Unauthorized!', 401);
    console.log(shop.Products);
    res
      .status(200)
      .json({ message: 'Shop products: ', products: shop.Products });
  }

  @catchError
  @requiredProps('name', 'description', 'price')
  @post('/product')
  @use(isAuth)
  async addProduct(req: Request, res: Response) {
    const { name, description, price } = req.body;
    const shop = await Shop.findById(req.userId).populate('Products');
    if (!shop) throw new CustomError('Unauthorized!', 401);
    let imagesUrls = [];
    const files = req.files as Express.Multer.File[];
    if (!files[0]) throw new CustomError('Provide one image at least!', 400);
    for (let file of files) {
      if (file.path) imagesUrls.push(file.path);
    }
    const product = new Product({ name, description, price, imagesUrls });
    await product.save();
    shop.Products.push(product._id);
    await shop.save();
    res.status(201).json({ message: 'Product created successfully' });
  }

  @catchError
  @put('/product/:productId')
  @use(isAuth)
  async editProduct(req: Request, res: Response) {
    const { name, description, price } = req.body;
    const { productId } = req.params;
    const shop = await Shop.findById(req.userId).populate('Products');
    if (!shop) throw new CustomError('Unauthorized!', 401);
    let imagesUrls = [];
    const files = req.files as Express.Multer.File[];
    if (files[0])
      for (let file of files) {
        if (file.path) imagesUrls.push(file.path);
      }
    const product = await Product.findById(productId);
    if (!product) throw new CustomError('Product not found!', 404);
    const products_ids = shop.Products.map((p) => p._id.toString());
    if (!products_ids.includes(product._id.toString()))
      throw new CustomError('Unauthorized!', 401);
    product.name = name || product.name;
    product.description = description || product.description;
    product.price = price || product.price;
    if (imagesUrls[0]) product.imagesUrls = imagesUrls;
    await product.save();
    res.status(201).json({ message: 'Product updated.' });
  }

  @catchError
  @del('/product/:productId')
  @use(isAuth)
  async deleteProduct(req: Request, res: Response) {
    const { productId } = req.params;
    const shop = await Shop.findById(req.userId).populate('Products');
    if (!shop) throw new CustomError('Unauthorized!', 401);
    const product = await Product.findById(productId);
    if (!product) throw new CustomError('Product not found!', 404);
    const products_ids = shop.Products.map((p) => p._id.toString());
    if (!products_ids.includes(product._id.toString()))
      throw new CustomError('Unauthorized!', 401);
    const productIndex = products_ids.indexOf(product._id.toString());
    shop.Products.splice(productIndex, 1);
    await product.deleteOne();
    await shop.save();
    res.status(200).json({ message: 'Product deleted.' });
  }
}
