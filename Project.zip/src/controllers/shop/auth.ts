import { controller, get, post, put, requiredProps } from '../../decorators';
import { CustomError } from '../../interfaces/customError';
import { catchError } from '../../decorators/catchError';
import { Request, Response, NextFunction } from 'express';
import { hash, compare } from 'bcrypt';
import { sign } from 'jsonwebtoken';
import { Shop } from '../../models';
import { createTransport } from 'nodemailer';

@controller('/shop')
class CustomerAuthController {
  @catchError
  @post('/signup')
  async signup(req: Request, res: Response): Promise<void> {
    const {
      email,
      password,
      name,
      phone,
      address,
      description,
      ShopCategories,
    } = req.body;
    let photoUrl = '';
    if (req.files) {
      const files = req.files as Express.Multer.File[];
      photoUrl = files[0].path;
    }
    const hashedPassword = await hash(password, 12);
    const shop = new Shop({
      email,
      password: hashedPassword,
      name,
      phone,
      address,
      description,
      ShopCategories,
      photoUrl,
    });
    await shop.save();
    const jwt = sign(
      {
        email: shop.email,
        userId: shop._id,
      },
      process.env.jwt_secrete_string as string,
      { expiresIn: '30d' }
    );
    res.status(201).json({ message: 'Shop signed up successfully.', JWT: jwt });
  }

  @catchError
  @post('/login')
  async login(req: Request, res: Response): Promise<void> {
    const { email, password } = req.body;
    const shop = await Shop.findOne({ email });
    if (!shop) {
      const error = new CustomError('email is not found!');
      error.statusCode = 422;
      throw error;
    }
    const isEqual = await compare(password, shop.password);
    if (!isEqual) {
      const error = new CustomError('Wrong password!');
      error.statusCode = 422;
      throw error;
    }
    const jwt = sign(
      {
        email: shop.email,
        userId: shop._id,
      },
      process.env.jwt_secrete_string as string,
      { expiresIn: '30d' }
    );
    res.status(200).json({ message: 'Loged in successfully.', JWT: jwt });
  }

  @catchError
  @requiredProps('email')
  @post('/forgotPassword')
  async forgotPassword(req: Request, res: Response) {
    const { email } = req.body;
    const shop = await Shop.findOne({ email });
    if (!shop) throw new CustomError('No shop found with this email!', 404);
    let transporter = createTransport({
      service: 'gmail',
      auth: {
        user: process.env.MAIL_USERNAME,
        pass: process.env.MAIL_PASSWORD,
      },
    });
    const resetToken = Math.floor(Math.random() * 1000000);
    shop.resetToken = `${resetToken}`;
    shop.resetTokenExpiration = new Date(Date.now() + 3600000);
    await shop.save();
    const mailOptions = {
      from: 'TeleJob',
      to: email,
      subject: 'Reset your TeleJob shop_account password:',
      text: `Your reset_password token is: ${shop.resetToken}`,
    };
    const mailInfo = await transporter.sendMail(mailOptions);
    res.status(200).json({
      message:
        'We send a token to your email, Check it and use it to reset your password.',
    });
  }

  @catchError
  @requiredProps('email', 'resetToken', 'password')
  @put('/resetPassword')
  async resetPassword(req: Request, res: Response) {
    const { email, resetToken, password } = req.body;
    const shop = await Shop.findOne({ email });
    if (!shop) throw new CustomError('No shop found with this email!', 404);
    if (shop.resetToken !== resetToken)
      throw new CustomError('Wrong reset_password token!', 422);
    if (shop.resetTokenExpiration && +shop.resetTokenExpiration < Date.now())
      throw new CustomError('Expired reset_password token!', 422);

    const hashedPassword = await hash(password, 12);
    shop.password = hashedPassword;
    shop.resetToken = null;
    shop.resetTokenExpiration = null;
    await shop.save();
    res.status(201).json({ message: 'Password updated successfully.' });
  }
}
