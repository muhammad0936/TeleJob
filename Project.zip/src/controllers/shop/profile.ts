import {
  controller,
  catchError,
  requiredProps,
  get,
  use,
  put,
  post,
  del,
} from '../../decorators';
import { Document, Schema, Types } from 'mongoose';
import { CustomError } from '../../interfaces/customError';
import { Request, Response, NextFunction } from 'express';
import { hash, compare } from 'bcrypt';
import { sign } from 'jsonwebtoken';
import {
  JobCategory,
  JobRequest,
  Worker,
  Customer,
  Shop,
  ShopCategory,
} from '../../models';
import { isAuth } from '../../middlewares/isAuth';
const { ObjectId } = Types;
@controller('/shop')
class worker {
  @catchError
  @get('/profile')
  @use(isAuth)
  async getProfile(req: Request, res: Response) {
    const shop = await Shop.findById(req.userId)
      .populate({ path: 'ShopCategories', select: 'name' })
      .select('name email description phone address photoUrl');
    if (!shop) throw new CustomError('Not authenticated!', 401);
    res.status(200).json({ message: 'Profile data: ', shop });
  }
  @catchError
  @put('/profile')
  @use(isAuth)
  async editProfile(req: Request, res: Response, next: NextFunction) {
    let {
      name,
      phone,
      address,
      description,
      addedShopCategories,
      deletedShopCategories,
    } = req.body;
    // if string convert it to an array
    if (typeof addedShopCategories !== 'object')
      addedShopCategories = addedShopCategories ? [addedShopCategories] : [];
    if (typeof deletedShopCategories !== 'object') {
      deletedShopCategories = deletedShopCategories
        ? [deletedShopCategories]
        : [];
    }
    const shop = await Shop.findById(req.userId);
    if (!shop) throw new CustomError('Not authenticated!', 401);
    shop.name = name || shop.name;
    shop.phone = phone || shop.phone;
    shop.address = address || shop.address;
    shop.description = description || shop.description;
    const ShopCategoriesPromises = addedShopCategories.map(
      async (sc: string) => {
        const isScExists = await ShopCategory.exists({ _id: sc });
        if (!isScExists)
          throw new CustomError(
            'Some added shop categoris not found, Check the provided IDs!',
            400
          );
      }
    );
    await Promise.all(ShopCategoriesPromises);
    console.log(deletedShopCategories);
    deletedShopCategories.map((sc: string) => {
      const _id = new ObjectId(sc);
      if (!shop.ShopCategories.includes(_id))
        throw new CustomError(
          'Some deleted shop categoris not found, Check the provided IDs!',
          400
        );
    });
    shop.ShopCategories = shop.ShopCategories.concat(addedShopCategories);
    shop.ShopCategories = shop.ShopCategories.filter(
      (jc) => !deletedShopCategories.includes(jc.toString())
    );
    const files = req.files as Express.Multer.File[];
    if (files[0]) shop.photoUrl = files[0].path;
    await shop.save();
    res.status(201).json({ message: 'Profile updated.' });
  }
}
