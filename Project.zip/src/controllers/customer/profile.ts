import {
  controller,
  catchError,
  requiredProps,
  get,
  use,
  put,
  post,
  del,
} from '../../decorators';
import { Document, Schema } from 'mongoose';
import { CustomError } from '../../interfaces/customError';
import { Request, Response, NextFunction } from 'express';
import { hash, compare } from 'bcrypt';
import { sign } from 'jsonwebtoken';
import { JobCategory, JobRequest, Worker, Customer } from '../../models';
import { isAuth } from '../../middlewares/isAuth';

@controller('/customer')
class customer {
  @catchError
  @get('/profile')
  @use(isAuth)
  async getProfile(req: Request, res: Response) {
    const customer = await Customer.findById(req.userId).select(
      'name email phone address'
    );
    if (!customer) throw new CustomError('Not authenticated!', 401);
    res.status(200).json({ message: 'Profile data: ', customer });
  }
  @catchError
  @put('/profile')
  @use(isAuth)
  async editProfile(req: Request, res: Response) {
    const { name, phone, address } = req.body;
    const customer = await Customer.findById(req.userId);
    if (!customer) throw new CustomError('Not authenticated!', 401);
    customer.name = name || customer.name;
    customer.phone = phone || customer.phone;
    customer.address = address || customer.address;
    await customer.save();
    res.status(201).json({ message: 'Profile updated.' });
  }
}
