import {
  controller,
  catchError,
  requiredProps,
  get,
  use,
  post,
  del,
} from '../../decorators';
import { Document, Schema } from 'mongoose';
import { CustomError } from '../../interfaces/customError';
import { Request, Response, NextFunction } from 'express';
import { hash, compare } from 'bcrypt';
import { sign } from 'jsonwebtoken';
import { JobCategory, JobRequest, Worker, Customer } from '../../models';
import { isAuth } from '../../middlewares/isAuth';

@controller('/customer')
class customer {
  @catchError
  @get('/workers')
  // @use(isAuth)
  async getWorkers(req: Request, res: Response) {
    const workers = await Worker.find().select('_id name description address');
    res.status(200).json({ message: 'Workers: ', workers });
  }

  @catchError
  @get('/worker/:workerId')
  async getSingleWorker(req: Request, res: Response) {
    const { workerId } = req.params;
    const worker = await Worker.findById(workerId)
      .populate({ path: 'JobCategories', select: 'name' })
      .select('-createdAt -updatedAt -__v -password');
    if (!worker) throw new CustomError('Worker not found!', 404);
    res.status(200).json({
      message: 'Worker info: ',
      worker,
    });
  }
}
