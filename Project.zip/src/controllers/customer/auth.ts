import {
  controller,
  catchError,
  requiredProps,
  get,
  put,
  post,
} from '../../decorators';
import { CustomError } from '../../interfaces/customError';
import { Request, Response, NextFunction } from 'express';
import { hash, compare } from 'bcrypt';
import { sign } from 'jsonwebtoken';
import { Customer } from '../../models';
import { createTransport } from 'nodemailer';

@controller('/customer')
class customer {
  @catchError
  @requiredProps('email', 'password', 'name', 'phone')
  @post('/signup')
  async signup(req: Request, res: Response): Promise<void> {
    const { email, password, name, phone, address } = req.body;
    const hashedPassword = await hash(password, 12);
    const customer = new Customer({
      email,
      password: hashedPassword,
      name,
      phone,
      address,
    });
    await customer.save();
    const jwt = sign(
      {
        email: customer.email,
        userId: customer._id,
      },
      process.env.jwt_secrete_string as string,
      { expiresIn: '30d' }
    );
    res
      .status(201)
      .json({ message: 'Customer signed up successfully.', JWT: jwt });
  }

  @catchError
  @requiredProps('email', 'password')
  @post('/login')
  async login(req: Request, res: Response): Promise<void> {
    const { email, password } = req.body;
    const customer = await Customer.findOne({ email });
    if (!customer) {
      const error = new CustomError('email is not found!');
      error.statusCode = 422;
      throw error;
    }
    const isEqual = await compare(password, customer.password);
    if (!isEqual) {
      const error = new CustomError('Wrong password!');
      error.statusCode = 422;
      throw error;
    }
    const jwt = sign(
      {
        email: customer.email,
        userId: customer._id,
      },
      process.env.jwt_secrete_string as string,
      { expiresIn: '30d' }
    );
    res.status(200).json({ message: 'Loged in successfully.', JWT: jwt });
  }

  @catchError
  @requiredProps('email')
  @post('/forgotPassword')
  async forgotPassword(req: Request, res: Response) {
    const { email } = req.body;
    const customer = await Customer.findOne({ email });
    if (!customer)
      throw new CustomError('No customer found with this email!', 404);
    let transporter = createTransport({
      service: 'gmail',
      auth: {
        user: process.env.MAIL_USERNAME,
        pass: process.env.MAIL_PASSWORD,
      },
    });
    const resetToken = Math.floor(Math.random() * 1000000);
    customer.resetToken = `${resetToken}`;
    customer.resetTokenExpiration = new Date(Date.now() + 3600000);
    await customer.save();
    const mailOptions = {
      from: 'TeleJob',
      to: email,
      subject: 'Reset your TeleJob customer_account password:',
      text: `Your reset_password token is: ${customer.resetToken}`,
    };
    const mailInfo = await transporter.sendMail(mailOptions);
    res.status(200).json({
      message:
        'We send a token to your email, Check it and use it to reset your password.',
    });
  }

  @catchError
  @requiredProps('email', 'resetToken', 'password')
  @put('/resetPassword')
  async resetPassword(req: Request, res: Response) {
    const { email, resetToken, password } = req.body;
    const customer = await Customer.findOne({ email });
    if (!customer) throw new CustomError('No user found with this email!', 404);
    if (customer.resetToken !== resetToken)
      throw new CustomError('Wrong reset_password token!', 422);
    if (
      customer.resetTokenExpiration &&
      +customer.resetTokenExpiration < Date.now()
    )
      throw new CustomError('Expired reset_password token!', 422);

    const hashedPassword = await hash(password, 12);
    customer.password = hashedPassword;
    customer.resetToken = null;
    customer.resetTokenExpiration = null;
    await customer.save();
    res.status(201).json({ message: 'Password updated successfully.' });
  }
}
