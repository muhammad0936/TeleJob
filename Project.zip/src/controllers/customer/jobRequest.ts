import {
  controller,
  catchError,
  requiredProps,
  get,
  use,
  post,
  del,
} from '../../decorators';
import fs from 'fs';
import { Document, Schema } from 'mongoose';
import { CustomError } from '../../interfaces/customError';
import { Request, Response, NextFunction } from 'express';
import { hash, compare } from 'bcrypt';
import { sign } from 'jsonwebtoken';
import { JobCategory, JobRequest, Worker, Customer } from '../../models';
import { isAuth } from '../../middlewares/isAuth';

@controller('/customer')
class customer {
  @catchError
  @post('/request')
  @use(isAuth)
  async sendJobRequest(req: Request, res: Response) {
    interface body {
      workerId: string;
      jobDescription?: string;
      JobCategories: object[];
    }
    var { workerId, jobDescription, JobCategories } = req.body as body;
    const customerId = req.userId;
    const customer = await Customer.findById(customerId);
    if (!customer) {
      throw new CustomError('Customer not found!', 404);
    }
    const worker = await Worker.findById(workerId);
    if (!worker) {
      throw new CustomError('Worker not found!', 404);
    }
    let imagesUrls = [];
    const files = req.files as Express.Multer.File[];
    if (!files[0]) throw new CustomError('Provide one image at least!', 400);
    for (let file of files) {
      if (file.path) imagesUrls.push(file.path);
    }
    const jobRequest = new JobRequest({
      customer: customerId,
      worker: workerId,
      jobDescription,
      imagesUrls,
      JobCategories,
    });
    await jobRequest.save();
    res.status(201).json({ message: 'Job request sent successfully.' });
  }
  @catchError
  @get('/requests')
  @use(isAuth)
  async getJobRequests(req: Request, res: Response) {
    const customerId = req.userId;
    const customer = await Customer.findById(customerId);
    if (!customer) throw new CustomError('Customer not found!', 404);
    const requests = await JobRequest.find({ customer: customerId })
      .populate({ path: 'worker', select: 'name' })
      .populate({ path: 'JobCategories', select: 'name' })
      .select('_id jobDescription status');
    res.status(200).json({ message: 'sent job requests: ', requests });
  }

  @catchError
  @get('/request/:requestId')
  @use(isAuth)
  async getSingleRequest(req: Request, res: Response) {
    const customerId = req.userId;
    const { requestId } = req.params;
    const customer = await Customer.findById(customerId);
    if (!customer) throw new CustomError('Customer not found!', 404);
    const request = await JobRequest.findById(requestId)
      .populate({ path: 'worker', select: 'name' })
      .populate({ path: 'JobCategories', select: 'name' })
      .select('jobDescription imagesUrls status createdAt endDate');
    if (!request) throw new CustomError('Job request not found!', 404);
    res.status(200).json({
      message: 'Job request information: ',
      request,
    });
  }

  @catchError
  @del('/request/:requestId')
  @use(isAuth)
  async cancelJobRequst(req: Request, res: Response) {
    const { requestId } = req.params;
    const request = await JobRequest.findById(requestId);
    if (!request) throw new CustomError('Job request not found!', 404);
    const customer = await Customer.findById(req.userId);
    if (!customer || customer._id.toString() !== request.customer?.toString())
      throw new CustomError('Not authorized to cancel this job request!', 401);
    request.imagesUrls.forEach((i) => {
      fs.unlink(i, (err) => {
        if (err) console.log(err);
      });
    });

    await request.deleteOne();
    res.status(200).json({ message: 'Job request deleted successfully.' });
  }
}
