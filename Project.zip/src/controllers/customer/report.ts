import {
  controller,
  catchError,
  requiredProps,
  get,
  use,
  post,
  del,
} from '../../decorators';
import { Document, Schema } from 'mongoose';
import { CustomError } from '../../interfaces/customError';
import { Request, Response, NextFunction } from 'express';
import { hash, compare } from 'bcrypt';
import { sign } from 'jsonwebtoken';
import {
  JobCategory,
  JobRequest,
  Worker,
  Customer,
  ReportType,
  Report,
} from '../../models';
import { isAuth } from '../../middlewares/isAuth';

@controller('/customer')
class customer {
  @catchError
  @get('/reportTypes')
  async getReportTypes(req: Request, res: Response) {
    const reportTypes = await ReportType.find({
      reportedType: 'Worker',
    }).select('_id name description');
    res.status(200).json({ message: 'Report types: ', reportTypes });
  }

  @catchError
  @requiredProps('workerId', 'requestId', 'reportTypeId')
  @post('/report')
  @use(isAuth)
  async reportWorker(req: Request, res: Response) {
    const { workerId, requestId, reportTypeId } = req.body;
    console.log(req.userId);
    const customer = await Customer.exists({ _id: req.userId });
    if (!customer) throw new CustomError('Unauthorized!', 401);
    const worker = await Worker.exists({ _id: workerId });
    if (!worker) throw new CustomError('Worker not found!', 404);
    const jobRequest = await JobRequest.exists({ _id: requestId });
    if (!jobRequest) throw new CustomError('Job request not found!', 404);
    const reportType = await ReportType.findById(reportTypeId).select(
      'reportedType'
    );
    if (!reportType) throw new CustomError('Report type not found!', 404);
    if (reportType?.reportedType !== 'Worker')
      throw new CustomError(
        "Invalid report type, The reportedType field must be 'Worker'.",
        422
      );
    const isReportExist = await Report.exists({
      customer: req.userId,
      worker: workerId,
      jobRequest: requestId,
      reportType: reportTypeId,
    });
    if (isReportExist)
      throw new CustomError(
        'You already reported this worker using same report type!',
        422
      );
    const report = new Report({
      customer: req.userId,
      worker: workerId,
      jobRequest: requestId,
      reportType: reportTypeId,
    });
    await report.save();
    res.status(201).json({ message: 'Worker reported successfully.' });
  }
}
