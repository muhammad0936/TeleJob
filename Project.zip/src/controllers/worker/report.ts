import {
  controller,
  catchError,
  requiredProps,
  get,
  use,
  put,
  post,
  del,
} from '../../decorators';
import { Document, Schema } from 'mongoose';
import { CustomError } from '../../interfaces/customError';
import { Request, Response, NextFunction } from 'express';
import { hash, compare } from 'bcrypt';
import { sign } from 'jsonwebtoken';
import {
  Report,
  JobCategory,
  Worker,
  Customer,
  JobRequest,
  Shop,
  Order,
  ReportType,
} from '../../models';
import { isAuth } from '../../middlewares/isAuth';
import { ResponseType, JobRequestStatus, OrderStatus } from '../../util/types';

@controller('/worker')
class worker {
  @catchError
  @get('/reportTypes')
  async getReportTypes(req: Request, res: Response) {
    const reportTypes = await ReportType.find({
      reportedType: 'Shop',
    }).select('_id name description');
    res.status(200).json({ message: 'Report types: ', reportTypes });
  }

  @catchError
  @requiredProps('shopId', 'orderId', 'reportTypeId')
  @post('/report')
  @use(isAuth)
  async reportShop(req: Request, res: Response) {
    const { shopId, orderId, reportTypeId } = req.body;
    console.log(req.userId);
    const worker = await Worker.exists({ _id: req.userId });
    if (!worker) throw new CustomError('Unauthorized!', 401);
    const shop = await Shop.exists({ _id: shopId });
    if (!shop) throw new CustomError('Shop not found!', 404);
    const order = await Order.findById(orderId);
    if (!order) throw new CustomError('Order not found!', 404);
    const reportType = await ReportType.findById(reportTypeId).select(
      'reportedType'
    );
    console.log(order.shop, shop._id);
    if (order.shop.toString() !== shop._id.toString())
      throw new CustomError('This order is not related to provided shop!', 400);
    if (!reportType) throw new CustomError('Report type not found!', 404);
    if (reportType?.reportedType !== 'Shop')
      throw new CustomError(
        "Invalid report type, The reportedType field must be 'Shop'.",
        422
      );
    const isReportExist = await Report.exists({
      worker: req.userId,
      shop: shopId,
      order: orderId,
      reportType: reportTypeId,
    });
    if (isReportExist)
      throw new CustomError(
        'You already reported this shop using same report type!',
        422
      );
    const report = new Report({
      worker: req.userId,
      shop: shopId,
      order: orderId,
      reportType: reportTypeId,
    });
    await report.save();
    res.status(201).json({ message: 'Shop reported successfully.' });
  }
}
