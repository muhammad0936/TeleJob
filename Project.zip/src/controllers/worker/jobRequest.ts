import {
  controller,
  catchError,
  requiredProps,
  get,
  use,
  put,
  post,
  del,
} from '../../decorators';
import { Document, Schema } from 'mongoose';
import { CustomError } from '../../interfaces/customError';
import { Request, Response, NextFunction } from 'express';
import { hash, compare } from 'bcrypt';
import { sign } from 'jsonwebtoken';
import { JobCategory, Worker, Customer, JobRequest } from '../../models';
import { isAuth } from '../../middlewares/isAuth';
import { ResponseType, JobRequestStatus } from '../../util/types';

@controller('/worker')
class worker {
  @catchError
  @get('/requests')
  @use(isAuth)
  async getJobRequests(req: Request, res: Response) {
    const workerId = req.userId;
    const worker = await Worker.findById(workerId);
    if (!worker) throw new CustomError('worker not found!', 404);
    const requests = await JobRequest.find({ worker: workerId })
      .select('_id jobDescription status')
      .populate({ path: 'customer', select: 'name' })
      .populate({ path: 'JobCategories', select: 'name' });
    res.status(200).json({ message: 'Recieved job requests: ', requests });
  }

  @catchError
  @get('/request/:requestId')
  @use(isAuth)
  async getSingleRequest(req: Request, res: Response) {
    const workerId = req.userId;
    const { requestId } = req.params;
    const worker = await Worker.findById(workerId);
    if (!worker) throw new CustomError('worker not found!', 404);
    const request = await JobRequest.findById(requestId)
      .populate({ path: 'customer', select: 'name' })
      .populate({ path: 'JobCategories', select: 'name' })
      .select('jobDescription imagesUrls status createdAt');
    if (!request) throw new CustomError('Job request not found!', 404);
    const endDate = new Date(request.createdAt.getTime() + 43200000);
    const returnedRequest = { _doc: {} };
    Object.assign(returnedRequest, request);
    res.status(200).json({
      message: 'Job request information: ',
      request: {
        ...returnedRequest._doc,
        endDate,
      },
    });
  }

  @catchError
  @put('/request/:requestId')
  @use(isAuth)
  async respondToRequest(req: Request, res: Response) {
    var { responseType }: { responseType: string } = req.body;
    const { requestId } = req.params;
    responseType = responseType.toLowerCase();
    if (responseType !== 'accept' && responseType !== 'reject')
      throw new CustomError(
        "Use valid response type, Either 'Accept' or 'Reject'.",
        422
      );
    const worker = await Worker.findById(req.userId);
    const jobRequest = await JobRequest.findById(requestId);
    if (!worker || jobRequest?.worker?.toString() !== worker._id.toString())
      throw new CustomError('Unauthorized!', 401);
    if (!jobRequest) throw new CustomError('Job request not found!', 404);
    if (jobRequest.status === JobRequestStatus.rejected)
      throw new CustomError('You already rejected this request!', 400);
    if (jobRequest.status === JobRequestStatus.accepted)
      throw new CustomError('You already accepted this request!', 400);
    if (+jobRequest.endDate < Date.now())
      throw new CustomError('This job request has expired!', 410);
    jobRequest.status = JobRequestStatus[`${responseType}ed`];
    jobRequest.endDate =
      responseType === 'accept'
        ? new Date(Date.now() + 7200000) //2hours to start the work
        : new Date(Date.now());
    await jobRequest.save();
    res.status(201).json({ message: `Job request ${responseType}ed.` });
  }
}
