import {
  controller,
  catchError,
  requiredProps,
  get,
  use,
  put,
  post,
  del,
} from '../../decorators';
import { Document, Schema } from 'mongoose';
import { CustomError } from '../../interfaces/customError';
import { Request, Response, NextFunction } from 'express';
import { hash, compare } from 'bcrypt';
import { sign } from 'jsonwebtoken';
import {
  JobCategory,
  Worker,
  Customer,
  JobRequest,
  Shop,
  Order,
} from '../../models';
import { isAuth } from '../../middlewares/isAuth';
import { ResponseType, JobRequestStatus, OrderStatus } from '../../util/types';

@controller('/worker')
class worker {
  @catchError
  @get('/shops')
  async getShops(req: Request, res: Response) {
    const shops = await Shop.find().select(
      '_id name phone description address photoUrl'
    );
    res.status(200).json({ message: 'Shops: ', shops });
  }

  @catchError
  @get('/shop/:shopId')
  async getSingleShop(req: Request, res: Response) {
    const { shopId } = req.params;
    const shop = await Shop.findById(shopId)
      .populate({ path: 'ShopCategories', select: 'name' })
      .select(
        '-password -resetToken -resetTokenExpiration -password -Products -updatedAt -__v '
      );
    if (!shop) throw new CustomError('Shop not found!', 404);
    res.status(200).json({ message: 'Shop: ', shop });
  }

  @catchError
  @get('/shopProducts/:shopId')
  async getShopProducts(req: Request, res: Response) {
    const { shopId } = req.params;
    const shop = await Shop.findById(shopId).populate({
      path: 'Products',
      select: 'name description price imagesUrls',
    });
    if (!shop) throw new CustomError('Shop not found!', 404);
    console.log(shop.Products);
    res
      .status(200)
      .json({ message: 'Shop products: ', products: shop.Products });
  }
}
