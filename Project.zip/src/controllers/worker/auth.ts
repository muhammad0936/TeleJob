import { controller, get, post, put, requiredProps } from '../../decorators';
import { CustomError } from '../../interfaces/customError';
import { catchError } from '../../decorators/catchError';
import { Request, Response, NextFunction } from 'express';
import { hash, compare } from 'bcrypt';
import { sign } from 'jsonwebtoken';
import { Worker } from '../../models';
import { createTransport } from 'nodemailer';

@controller('/worker')
class worker {
  @catchError
  @post('/signup')
  async signup(req: Request, res: Response): Promise<void> {
    const {
      email,
      password,
      name,
      phone,
      address,
      description,
      JobCategories,
    } = req.body;
    const hashedPassword = await hash(password, 12);
    const worker = new Worker({
      email,
      password: hashedPassword,
      name,
      phone,
      address,
      description,
      JobCategories,
    });
    await worker.save();
    const jwt = sign(
      {
        email: worker.email,
        userId: worker._id,
      },
      process.env.jwt_secrete_string as string,
      { expiresIn: '30d' }
    );
    res
      .status(201)
      .json({ message: 'Worker signed up successfully.', JWT: jwt });
  }

  @catchError
  @post('/login')
  async login(req: Request, res: Response): Promise<void> {
    const { email, password } = req.body;
    const worker = await Worker.findOne({ email });
    if (!worker) {
      const error = new CustomError('email is not found!');
      error.statusCode = 422;
      throw error;
    }
    const isEqual = await compare(password, worker.password);
    if (!isEqual) {
      const error = new CustomError('Wrong password!');
      error.statusCode = 422;
      throw error;
    }
    const jwt = sign(
      {
        email: worker.email,
        userId: worker._id,
      },
      process.env.jwt_secrete_string as string,
      { expiresIn: '30d' }
    );
    res.status(200).json({ message: 'Loged in successfully.', JWT: jwt });
  }
  @catchError
  @requiredProps('email')
  @post('/forgotPassword')
  async forgotPassword(req: Request, res: Response) {
    const { email } = req.body;
    const worker = await Worker.findOne({ email });
    if (!worker) throw new CustomError('No worker found with this email!', 404);
    let transporter = createTransport({
      service: 'gmail',
      auth: {
        user: process.env.MAIL_USERNAME,
        pass: process.env.MAIL_PASSWORD,
      },
    });
    const resetToken = Math.floor(Math.random() * 1000000);
    worker.resetToken = `${resetToken}`;
    worker.resetTokenExpiration = new Date(Date.now() + 3600000);
    await worker.save();
    const mailOptions = {
      from: 'TeleJob',
      to: email,
      subject: 'Reset your TeleJob worker_account password:',
      text: `Your reset_password token is: ${worker.resetToken}`,
    };
    const mailInfo = await transporter.sendMail(mailOptions);
    res.status(200).json({
      message:
        'We send a token to your email, Check it and use it to reset your password.',
    });
  }

  @catchError
  @requiredProps('email', 'resetToken', 'password')
  @put('/resetPassword')
  async resetPassword(req: Request, res: Response) {
    const { email, resetToken, password } = req.body;
    const worker = await Worker.findOne({ email });
    if (!worker) throw new CustomError('No worker found with this email!', 404);
    if (worker.resetToken !== resetToken)
      throw new CustomError('Wrong reset_password token!', 422);
    if (
      worker.resetTokenExpiration &&
      +worker.resetTokenExpiration < Date.now()
    )
      throw new CustomError('Expired reset_password token!', 422);

    const hashedPassword = await hash(password, 12);
    worker.password = hashedPassword;
    worker.resetToken = null;
    worker.resetTokenExpiration = null;
    await worker.save();
    res.status(201).json({ message: 'Password updated successfully.' });
  }
}
