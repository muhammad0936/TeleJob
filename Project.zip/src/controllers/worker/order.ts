import {
  controller,
  catchError,
  requiredProps,
  get,
  use,
  put,
  post,
  del,
} from '../../decorators';
import { Document, Schema } from 'mongoose';
import { CustomError } from '../../interfaces/customError';
import { Request, Response, NextFunction } from 'express';
import { hash, compare } from 'bcrypt';
import { sign } from 'jsonwebtoken';
import {
  JobCategory,
  Worker,
  Customer,
  JobRequest,
  Shop,
  Order,
} from '../../models';
import { isAuth } from '../../middlewares/isAuth';
import { ResponseType, JobRequestStatus, OrderStatus } from '../../util/types';

@controller('/worker')
class worker {
  @catchError
  @post('/order')
  @use(isAuth)
  @requiredProps('shopId', 'description')
  async order(req: Request, res: Response) {
    const worker = await Worker.findById(req.userId);
    if (!worker) throw new CustomError('Unauthorized!', 401);
    const { shopId, description } = req.body;
    const shop = await Shop.findById(shopId);
    if (!shop) throw new CustomError('Shop not found!', 404);
    const order = new Order({
      shop: shopId,
      worker: req.userId,
      description,
      location: '1lh4kl12j4kl1',
    });
    await order.save();
    res.status(201).json({ message: 'Order sent successfully.' });
  }

  @catchError
  @del('/order/:orderId')
  @use(isAuth)
  async cancelOrder(req: Request, res: Response) {
    const { orderId } = req.params;
    const order = await Order.findById(orderId);
    if (!order) throw new CustomError('Order not found!', 404);
    if (order.status === OrderStatus.accepted)
      throw new CustomError('This order has already accepted!', 400);
    await order.deleteOne();
    res.status(200).json({ message: 'Order deleted successfully.' });
  }

  @catchError
  @get('/orders')
  @use(isAuth)
  async getOrders(req: Request, res: Response) {
    const worker = await Worker.findById(req.userId);
    if (!worker) throw new CustomError('Unauthorized!', 401);
    const orders = await Order.find({ worker: req.userId })
      .populate({ path: 'shop', select: 'name' })
      .select('_id description status totlaPrice createdAt');
    res.status(200).json({ message: 'Your orders: ', orders });
  }

  @catchError
  @get('/order/:orderId')
  @use(isAuth)
  async getSingleOrder(req: Request, res: Response) {
    const { orderId } = req.params;
    const worker = await Worker.findById(req.userId);
    if (!worker) throw new CustomError('Unauthorized!', 401);
    const order = await Order.findById(orderId)
      .populate({ path: 'shop', select: 'name' })
      .populate({ path: 'worker', select: 'name' })
      .select('-updatedAt -__v');
    if (!order) throw new CustomError('Order not found!', 404);
    res.status(200).json({ message: 'Your orders: ', order });
  }
}
