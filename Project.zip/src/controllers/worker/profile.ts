import {
  controller,
  catchError,
  requiredProps,
  get,
  use,
  put,
  post,
  del,
} from '../../decorators';
import { Document, Schema, Types } from 'mongoose';
import { CustomError } from '../../interfaces/customError';
import { Request, Response, NextFunction } from 'express';
import { hash, compare } from 'bcrypt';
import { sign } from 'jsonwebtoken';
import { JobCategory, JobRequest, Worker, Customer } from '../../models';
import { isAuth } from '../../middlewares/isAuth';
const { ObjectId } = Types;
@controller('/worker')
class worker {
  @catchError
  @get('/profile')
  @use(isAuth)
  async getProfile(req: Request, res: Response) {
    const worker = await Worker.findById(req.userId)
      .populate({ path: 'JobCategories', select: 'name' })
      .select('name email description phone address');
    if (!worker) throw new CustomError('Not authenticated!', 401);
    res.status(200).json({ message: 'Profile data: ', worker });
  }
  @catchError
  @put('/profile')
  @use(isAuth)
  async editProfile(req: Request, res: Response, next: NextFunction) {
    let {
      name,
      phone,
      address,
      description,
      addedJobCategories,
      deletedJobCategories,
    } = req.body;
    if (typeof addedJobCategories !== 'object')
      addedJobCategories = addedJobCategories ? [addedJobCategories] : [];
    if (typeof deletedJobCategories !== 'object') {
      deletedJobCategories = deletedJobCategories ? [deletedJobCategories] : [];
    }
    const worker = await Worker.findById(req.userId);
    if (!worker) throw new CustomError('Not authenticated!', 401);
    worker.name = name || worker.name;
    worker.phone = phone || worker.phone;
    worker.address = address || worker.address;
    worker.address = description || worker.description;
    const jobCategoriesPromises = addedJobCategories.map(async (jc: string) => {
      const isJcExists = await JobCategory.exists({ _id: jc });
      if (!isJcExists)
        throw new CustomError(
          'Some added job categoris not found, Check the provided IDs!',
          400
        );
    });
    await Promise.all(jobCategoriesPromises);
    console.log(deletedJobCategories);
    deletedJobCategories.map((jc: string) => {
      const _id = new ObjectId(jc);
      if (!worker.JobCategories.includes(_id))
        throw new CustomError(
          'Some deleted job categoris not found, Check the provided IDs!',
          400
        );
    });
    worker.JobCategories = worker.JobCategories.concat(addedJobCategories);
    worker.JobCategories = worker.JobCategories.filter(
      (jc) => !deletedJobCategories.includes(jc.toString())
    );
    await worker.save();
    res.status(201).json({ message: 'Profile updated.' });
  }
}
