import { Request, Response } from 'express';
import {
  controller,
  catchError,
  requiredProps,
  use,
  get,
  post,
  put,
  del,
} from '../../decorators';
import { CustomError } from '../../interfaces/customError';
import { isAuth } from '../../middlewares/isAuth';
import { ShopCategory } from '../../models';
import { Role } from '../../util/types';
@controller('')
class shopCategory {
  @catchError
  @get('/shopCategories')
  @use(isAuth)
  async getShopCategories(req: Request, res: Response) {
    // if (req.role !== Role.admin) {
    //   const error = new CustomError('Unauthorized!');
    //   error.statusCode = 401;
    //   throw error;
    // }
    const shopCategories = await ShopCategory.find().select(
      '_id name description'
    );
    res.status(200).json({ message: 'Shop categories: ', shopCategories });
  }
}
