import { Request, Response } from 'express';
import {
  controller,
  catchError,
  requiredProps,
  use,
  get,
  post,
  put,
  del,
} from '../../decorators';
import { CustomError } from '../../interfaces/customError';
import { isAuth } from '../../middlewares/isAuth';
import { JobCategory } from '../../models';
import { Role } from '../../util/types';
@controller('')
class jobCategory {
  @catchError
  @get('/jobCategories')
  @use(isAuth)
  async getJobCategories(req: Request, res: Response) {
    const { name, description } = req.query;
    // if (req.role !== Role.admin) {
    //   const error = new CustomError('Unauthorized!');
    //   error.statusCode = 401;
    //   throw error;
    // }
    const jobCategories = await JobCategory.find().select(
      '_id name description'
    );
    res.status(200).json({ message: 'Job categories: ', jobCategories });
  }
}
