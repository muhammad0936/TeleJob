import { body, check } from 'express-validator';
export const loginValidator = [
  body('email').isEmail().withMessage('Enter a valid email!'),
  body('password').isString().isLength({min: 5, max: 20}).trim().withMessage('Password must be with 5=>20 length!')
]
