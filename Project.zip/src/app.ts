import express, { NextFunction, Request, Response } from 'express';
import bodyParser, { json, urlencoded } from 'body-parser';
import fs from 'fs';
import multer, { FileFilterCallback } from 'multer';
import './controllers/customer';
import './controllers/worker';
import './controllers/shop';
import './controllers/admin';
import './controllers/sharedEndPoints';
import { AppRouter } from './router';
import { CustomError } from './interfaces/customError';
import { connect } from 'mongoose';
const app = express();
import { config } from 'dotenv';
import path from 'path';
config();

const fileStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const folderPath = 'images'; // Specify the folder name

    // Check if the folder exists; if not, create it
    if (!fs.existsSync(folderPath)) {
      fs.mkdirSync(folderPath, { recursive: true });
    }
    cb(null, folderPath);
  },
  filename: (req, file, cb) => {
    cb(null, new Date().getTime() + '-' + file.originalname);
  },
});
const filter = (
  req: Request,
  file: Express.Multer.File,
  cb: FileFilterCallback
) => {
  if (
    file.mimetype === 'image/png' ||
    file.mimetype === 'image/jpg' ||
    file.mimetype === 'image/jpeg'
  ) {
    cb(null, true);
  } else {
    const error = new CustomError(
      'You are trying to upload files which are not images, Upload just images with png, jpg, or jpeg extention.'
    );
    error.statusCode = 422;
    cb(error);
  }
};

app.use(urlencoded());
app.use(json());
app.use(
  multer({ storage: fileStorage, fileFilter: filter }).array('images', 5)
);
app.use('/images', express.static(path.join(__dirname, '../images')));
app.use(AppRouter.getInstance());
app.use('/', (req, res, next) => {
  res.status(404).send('Page not found!');
});
app.use((err: any, req: Request, res: Response, next: NextFunction): void => {
  console.log(err);
  err = err[0] ? err : [err];
  res.status(err[0].statusCode).json({
    message: `An error occured: `,
    data: err.map((i: any) => i.message),
  });
});
try {
  connect(process.env.MONGO_URI || '', {})
    .then((resule) => {
      console.log('Connected successfully');
      app.listen(process.env.PORT || 3000, () => {
        console.log(`App listening on port ${process.env.PORT || 3000}.`);
      });
    })
    .then((err: any) => {
      if (err) console.log('connection to the database failed!');
    });
} catch (err) {
  console.log(err);
}
