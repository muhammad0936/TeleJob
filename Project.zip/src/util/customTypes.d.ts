import jwt from 'jsonwebtoken';
import { Request } from 'express';
import { Role } from './types';
declare module 'jsonwebtoken' {
  export interface ExtendedJwtPayload extends jwt.JwtPayload {
    userId: string;
    email: string;
    role: Role;
  }
}
declare global {
  namespace Express {
    interface Request {
      userId?: string;
      role?: Role;
    }
  }
}
