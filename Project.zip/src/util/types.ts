export enum Role {
  admin = 'admin',
  customer = 'Customer',
  worker = 'Worker',
  shop = 'Shop',
}
export enum ReportedType {
  worker = 'Worker',
  shop = 'Shop',
}
export enum ResponseType {
  accept = 'Accept',
  reject = 'Reject',
}
export enum JobRequestStatus {
  pending = 'Pending',
  accepted = 'Accepted',
  rejected = 'Rejected',
}

export enum OrderStatus {
  pending = 'Pending',
  accepted = 'Accepted',
  rejected = 'Rejected',
}
