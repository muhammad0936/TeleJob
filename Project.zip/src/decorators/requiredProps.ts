import 'reflect-metadata';
import { MetadataKeys } from './metadataKeys';
import { CustomError } from '../interfaces/customError';

export function requiredProps(...keys: string[]) {
  return function (target: any, key: string, desc: PropertyDescriptor) {
    const method = desc.value;
    desc.value = async function (...args: any[]) {
      const req = args[0];
      const missedProperties: string[] = [];
      for (let requiredProperty of keys) {
        if (!req.body[requiredProperty]) {
          missedProperties.push(`{ ${requiredProperty} } property is missing!`);
        }
      }
      if (missedProperties[0]) {
        const error = new CustomError('Required data is missing!');
        error.statusCode = 400;
        error.data = missedProperties;
        throw error;
      }
      await method(...args);
    };
  };
}
