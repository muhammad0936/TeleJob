export enum Methods {
  get = 'get',
  post = 'post',
  patch = 'patch',
  put = 'put',
  del = 'delete',
}
