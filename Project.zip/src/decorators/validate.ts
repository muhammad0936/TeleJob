import 'reflect-metadata';
import { RequestHandler } from 'express';
import { MetadataKeys } from './metadataKeys';
import {
  ExpressValidator,
  ValidationChain,
  ValidationError,
  validationResult,
} from 'express-validator';
import fs from 'fs';

export function validate(middleware: RequestHandler | ValidationChain[]) {
  return function (target: any, key: string, desc: PropertyDescriptor) {
    const middlewares =
      Reflect.getMetadata(MetadataKeys.middleware, target, key) || [];

    Reflect.defineMetadata(
      MetadataKeys.middleware,
      [...middlewares, middleware],
      target,
      key
    );

    const method = desc.value;
    desc.value = async function (...args: any[]) {
      const next = args[args.length - 1];
      try {
        const req = args[0];
        const result = validationResult(req);
        if (!result.isEmpty()) {
          console.log(result.array());
          throw result.array().map((i: ValidationError) => {
            return { message: i.msg, path: i.type, statusCode: 422 };
          });
        }
      } catch (err) {
        next(err);
      }
      await method(...args);
    };
  };
}
