import fs from 'fs';
export function catchError(target: any, key: string, desc: PropertyDescriptor) {
  const method = desc.value;
  desc.value = async function (...args: any[]) {
    const next = args[args.length - 1];
    try {
      await method(...args);
    } catch (err: any) {
      if (args[0].files) {
        const files = args[0].files as Express.Multer.File[];
        files.map((file) => {
          fs.unlink(file.path, (err) => {
            if (err) console.log(err);
          });
        });
      }
      if (!err.statusCode) err.statusCode = err[0].statusCode || 500;
      next(err);
    }
  };
}
