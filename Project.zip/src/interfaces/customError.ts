export class CustomError extends Error {
  statusCode: number;
  data?: string[];
  constructor(message: string, statusCode?: number, data?: string[]) {
    super(message);
    this.statusCode = statusCode || 500;
    this.data = data || [];
  }
}
