import { NextFunction, Request, Response } from 'express';
import { verify, ExtendedJwtPayload } from 'jsonwebtoken';
import { CustomError } from '../interfaces/customError';
export const isAuth = (req: Request, res: Response, next: NextFunction) => {
  try {
    let jwt = req.get('Authorization') || '';
    if (!jwt) {
      const error = new CustomError('Not authenticated!');
      error.statusCode = 401;
      throw error;
    }
    jwt = jwt.split(' ')[1];
    const payload = verify(jwt, process.env.jwt_secrete_string as string);
    if (!payload) {
      const error = new CustomError('Not authenticated!');
      error.statusCode = 401;
      throw error;
    }
    const jwtPayload = payload as ExtendedJwtPayload;
    req.userId = jwtPayload.userId;
    req.role = jwtPayload.role;
    next();
  } catch (err: any) {
    const error = new CustomError(
      err.message || 'Not authenticated!',
      err.statusCode || 401
    );
    next(error);
  }
};
