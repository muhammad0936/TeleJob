import { Schema, model } from 'mongoose';

const { ObjectId } = Schema.Types;

const reportSchema = new Schema(
  {
    customer: {
      type: ObjectId,
      index: true,
      ref: 'Customer',
    },
    worker: {
      type: ObjectId,
      index: true,
      ref: 'Worker',
    },
    shop: {
      type: ObjectId,
      index: true,
      ref: 'Shop',
    },
    jobRequest: {
      type: ObjectId,
      ref: 'JobRequest',
    },
    order: {
      type: ObjectId,
      ref: 'Order',
    },
    reportType: {
      type: ObjectId,
      ref: 'ReportType',
    },
  },
  { timestamps: true }
);

export const Report = model('Report', reportSchema);
