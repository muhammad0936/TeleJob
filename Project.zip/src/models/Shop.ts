import { Schema, model } from 'mongoose';
const { ObjectId } = Schema.Types;
const ShopSchema = new Schema(
  {
    name: {
      type: String,
      required: true,
    },
    description: String,
    email: {
      type: String,
      required: true,
      unique: true,
    },
    password: {
      type: String,
      required: true,
    },
    phone: {
      type: String,
      required: true,
    },
    address: {
      type: String,
      required: true,
    },
    location: String,
    photoUrl: String,
    ShopCategories: [
      {
        type: Schema.Types.ObjectId,
        required: true,
        ref: 'ShopCategory',
      },
    ],
    Products: [
      {
        type: Schema.Types.ObjectId,
        required: true,
        ref: 'Product',
      },
    ],
    resetToken: String,
    resetTokenExpiration: Date,
  },
  { timestamps: true }
);

export const Shop = model('Shop', ShopSchema);
