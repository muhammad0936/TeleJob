import { Schema, model } from 'mongoose';
const JobCategorySchema = new Schema(
  {
    name: {
      type: String,
      required: true,
      unique: true,
    },
    description: {
      type: String,
      required: true,
      unique: true,
    },
  },
  { timestamps: true }
);

export const JobCategory = model('JobCategory', JobCategorySchema);
