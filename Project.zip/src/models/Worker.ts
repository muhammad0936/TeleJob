import { Schema, model } from 'mongoose';
const { ObjectId } = Schema.Types;
const WorkerSchema = new Schema(
  {
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
    },
    password: {
      type: String,
      required: true,
    },
    phone: {
      type: String,
      required: true,
    },
    address: {
      type: String,
      required: true,
    },
    description: { type: String, default: '' },
    location: {
      type: String,
    },
    JobCategories: [
      {
        type: ObjectId,
        ref: 'JobCategory',
      },
    ],
    resetToken: String,
    resetTokenExpiration: Date,
  },
  { timestamps: true }
);

export const Worker = model('Worker', WorkerSchema);
