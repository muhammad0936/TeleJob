import { Schema, model } from 'mongoose';

const CustomerSchema = new Schema(
  {
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
    },
    password: {
      type: String,
      required: true,
    },
    phone: {
      type: String,
      required: true,
    },
    address: {
      type: String,
    },
    location: {
      type: String,
    },
    resetToken: String,
    resetTokenExpiration: Date,
  },
  { timestamps: true, autoCreate: true }
);

export const Customer = model('Customer', CustomerSchema);
