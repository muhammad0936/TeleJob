import { Schema, model } from 'mongoose';

const { ObjectId } = Schema.Types;

const OrderSchema = new Schema(
  {
    shop: {
      type: ObjectId,
      required: true,
      ref: 'Shop',
      index: true,
    },
    worker: {
      type: ObjectId,
      required: true,
      ref: 'Worker',
      index: true,
    },
    description: {
      type: String,
      required: true,
    },
    status: {
      type: String,
      required: true,
      enum: ['Pending', 'Accepted', 'Rejected'],
      default: 'Pending',
    },
    location: {
      type: String,
      required: true,
    },
    totalPrice: Number,
    products: [
      {
        info: String,
        price: Number,
        quantity: Number,
      },
    ],
    endDate: { type: Schema.Types.Date, default: Date.now() + 43200000 },
  },
  { timestamps: true }
);

export const Order = model('Order', OrderSchema);
