import { Schema, model } from 'mongoose';
import { JobRequestStatus } from '../util/types';

const { ObjectId } = Schema.Types;

const RequestSchema = new Schema(
  {
    customer: {
      type: ObjectId,
      requierd: true,
      ref: 'Customer',
      index: true,
    },
    worker: {
      type: ObjectId,
      requierd: true,
      ref: 'Worker',
      index: true,
    },
    jobDescription: {
      type: String,
      required: true,
    },
    location: {
      type: String,
      // required: true,
    },
    imagesUrls: [String],
    status: {
      type: String,
      enum: JobRequestStatus,
      default: 'Pending',
      required: true,
    },
    JobCategories: [
      {
        type: ObjectId,
        ref: 'JobCategory',
      },
    ],
    endDate: { type: Schema.Types.Date, default: Date.now() + 43200000 },
  },
  { timestamps: true }
);

export const JobRequest = model('JobRequest', RequestSchema);
