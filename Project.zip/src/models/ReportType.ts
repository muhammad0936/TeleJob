import { Schema, model } from 'mongoose';

const ReportTypetSchema = new Schema(
  {
    name: {
      type: String,
      required: true,
      unique: true,
    },
    description: {
      type: String,
      required: true,
      unique: true,
    },
    reportedType: {
      type: String,
      enum: ['Worker', 'Shop'],
      required: true,
    },
  },
  { timestamps: true }
);

export const ReportType = model('ReportType', ReportTypetSchema);
